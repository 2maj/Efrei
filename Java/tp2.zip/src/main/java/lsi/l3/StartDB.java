/*
 * EFREI Student
 * Author: Moussa ADJI
 * Git: https://github.com/2maj/
 * Mail: adjimahamat@gmail.com
 */
package lsi.l3;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;

public class StartDB {
    private String url;
    private String user;
    private String pwd;
    private Connection connection;
    private Statement stmt;
    private ResultSet rs;
    
    public StartDB(String url, String user, String pwd){
        this.url= url;
        this.user=user;
        this.pwd=pwd;
    }
    
    public StartDB(){}
    
    public Connection connect(){
        try {
            this.connection = DriverManager.getConnection(this.url, this.user, this.pwd);
        } catch (SQLException ex) {
            Logger.getLogger(StartDB.class.getName()).log(Level.SEVERE, null, ex);
        }
        return this.connection;
    }
 
    public ResultSet createRequest(String req){
       
        try {
            this.stmt = this.connection.createStatement();
            rs = this.stmt.executeQuery(req);
        } catch (SQLException ex) {
            Logger.getLogger(StartDB.class.getName()).log(Level.SEVERE, null, ex);
        }
        return rs;
    }
    
}
